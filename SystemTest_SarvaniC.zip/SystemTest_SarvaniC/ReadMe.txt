Common Points :
---------------
Use the PSD or PNG file as per your convenient to design the web page.
Web page should compatible with chrome, firefox, IE10+.
Don't use any frameworks. 
Code should be start from scratch.
Use media query to make the page responsive for tablet.


